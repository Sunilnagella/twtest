describe('Basic Search Flow Test', () => {
    beforeEach(() => {
        cy.visit('https://marsair.recruiting.thoughtworks.net/SunilJoseph');
    });

    it.only('Should display appropriate message when user enters invalid return date', () => {
        cy.get('#departing').select('July');
        cy.get('#returning').select('December');
        cy.get('input[value="Search"]').click();
        cy.get('a').contains('Back').click();


    });

});