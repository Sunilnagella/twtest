describe('Basic Search Flow Test', () => {
  beforeEach(() => {
    cy.visit('https://marsair.recruiting.thoughtworks.net/SunilJoseph');
  });

  it('Should verify that the search form contains "departure" and "return" fields', () => {
    cy.get('#departing').should('be.visible');
    cy.get('label[for="departing"]').should('have.text', 'Departing');

    cy.get('#returning').should('be.visible');
    cy.get('label[for="returning"]').should('have.text', 'Returning');
  });

  it.only('Should display appropriate message when seats are available', () => {
    cy.get('#departing').select('July');
    cy.get('#returning').select('December (two years from now)');
    cy.get('input[value="Search"]').click();
    cy.get('a').contains('Back').click();


    //cy.get('.message').should('contain.text', 'Seats available! Call 0800 MARSAIR to book!');

  });

  it.only('Should display appropriate message when seats are not available', () => {
    cy.get('#departing').select('July');
    cy.get('#returning').select('December (next year)');
    cy.get('input[value="Search"]').click();


    //cy.get('.message').should('contain.text', 'Sorry, no seats are available.');
  });
});

