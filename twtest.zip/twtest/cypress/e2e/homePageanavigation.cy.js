describe('Basic Search Flow Test', () => {
    beforeEach(() => {
      cy.visit('SunilJoseph');
    });
    it('Shoud display the "Book a ticket to the red planet now!" on the home page', () => {
        cy.get('form>h3').should('have.text','Book a ticket to the red planet now!')
  
      
      });
  
    it.only('Should navigate to homepage when click on MarsAir logo', () => {
      cy.get('#departing').select('July');
      cy.get('#returning').select('December (two years from now)');
      cy.get('input[value="Search"]').click();
      cy.get('h1 > a').click();
      cy.title().should('eq', 'Mars Airlines: Home');

    
    });
});