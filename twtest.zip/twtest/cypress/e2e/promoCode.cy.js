describe('Promotion code test cases', () => {
  beforeEach(() => {
    cy.visit('https://marsair.recruiting.thoughtworks.net/SunilJoseph');
  });

  it.only('Verify Search results with valid Promo code', () => {
    // Select departure and return dates
    cy.get('#departing').select('July');
    cy.get('#returning').select('December (two years from now)');

    // Enter promotional code
    cy.get('#promotional_code').type('AF3-FJK-418');

    // Click on the search button
    cy.get('input[value="Search"]').click();

    // Click the back link to navigate back
    cy.get('a').contains('Back').click();


  });

  it.only('Verify Search results with invalid Promo code', () => {
    // Select departure and return dates
    cy.get('#departing').select('July');
    cy.get('#returning').select('December (two years from now)');

    // Enter promotional code
    cy.get('#promotional_code').type('AF1-FJK-418');

    // Click on the search button
    cy.get('input[value="Search"]').click();

    // Click the back link to navigate back
    cy.get('a').contains('Back').click();


  });

});
