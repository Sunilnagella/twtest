const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    supportFile: 'cypress/support/e2e.js',
    baseUrl: 'https://marsair.recruiting.thoughtworks.net/',
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },
  pageLoadTimeout	: 10000,
});
